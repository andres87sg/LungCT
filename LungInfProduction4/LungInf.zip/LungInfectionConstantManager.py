# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 08:44:59 2021
@author: Andres
"""

WinWidth=1500
WinLength=-500

imgnormsize = [512,512]
inputimgCNNscale = 4

SEsize = 5
#kernel = np.ones((5, 5), np.uint8)